# Hierarchical Information-Reality Model (HIRM)
## Standardized Terminology Reference Document

**Version:** 1.0  
**Date:** January 25, 2025  
**Status:** Official project reference  
**Purpose:** Maintain consistency across all academic papers, presentations, and documentation

---

## FRAMEWORK NAMING

### Official Academic Name
**Hierarchical Information-Reality Model (HIRM)**

**Usage:**
- First mention: "Hierarchical Information-Reality Model (HIRM)"
- Subsequent mentions: "HIRM" or "the framework"
- Paper titles: Use descriptive component names, not "HIRM" directly
- Avoid: "Ouroboros Observer" in academic papers (save for popular communication)

---

## CORE TERMINOLOGY

### Layer Architecture

#### Layer 1: Information Substrate
**Primary Terms (use contextually):**
1. **Quantum Information Layer (QIL)** - Use in mathematical/physics contexts
2. **Persistent Information Structure (PIS)** - Use in conceptual/neuroscience contexts

**Definition:** The substrate of conserved quantum information that persists across state-space bifurcations, independent of classical spacetime coordinates.

**Mathematical Notation:** Î¨_PIS or Q_PIS

**Legacy Term:** "Quantum DNA" (popular communication only)

**Usage Guidelines:**
- Physics papers: "quantum information layer"
- Neuroscience papers: "persistent information structure"  
- When emphasizing conservation: "persistent information structure"
- When emphasizing quantum formalism: "quantum information layer"

---

#### Layer 2: Processing Substrate
**Official Term:** **Consciousness Computation Layer (CCL)**

**Definition:** The intermediate scale where information integration, self-reference, and consciousness emergence occur through computational processes operating on the quantum information layer.

**Mathematical Notation:** Î¨_CCL or CCL

**Key Components:**
- Î¦(t): Integrated information
- R(t): Self-reference completeness
- D(t): Dimensional embedding
- C(t) = Î¦(t) Ã— R(t) Ã— D(t): Consciousness measure

**Legacy Term:** "Layer 2" or "Consciousness layer" (popular communication)

---

#### Layer 3: Observational Substrate
**Official Term:** **Macroscopic Observational Layer (MOL)**

**Definition:** The classical scale of observable physical reality where measurement outcomes manifest and spacetime emerges as an effective description.

**Mathematical Notation:** Î¨_MOL or MOL

**Legacy Term:** "Physical reality layer" or "The display" (popular communication)

---

### Critical Threshold

**Official Term:** **C-critical** or **C_critical** or **C***

**Full Name:** Critical Consciousness Threshold

**Definition:** The specific threshold of integrated self-reference (C = Î¦ Ã— R Ã— D) at which self-reference-induced decoherence occurs, triggering state-space bifurcation.

**Mathematical Expression:** C_crit â‰ˆ 8.3 Â± 0.6 bits (preliminary calculation)

**Usage:**
- Equations: C_crit or C*
- Text: "C-critical" or "the critical threshold"
- Full form on first mention: "critical consciousness threshold (C_crit)"

**Alternative phrasing:**
- "Self-reference phase transition threshold"
- "Critical information integration threshold"
- Avoid: "The moment of collapse" (imprecise)

---

### Phase Transition Event

**Official Term:** **Self-Reference-Induced Decoherence (SRID)**

**Definition:** The quantum decoherence process triggered when a system's self-reference completeness reaches C_critical, resulting in state-space bifurcation while conserving information in the persistent information structure.

**Abbreviation:** SRID (optional, spell out on first use)

**Usage:**
- Technical papers: "self-reference-induced decoherence"
- When emphasizing mechanism: "SRID process"
- When emphasizing causation: "consciousness-mediated decoherence"

**Legacy Term:** "Ouroboros Event" (popular communication only)

**Related Terms:**
- State-space bifurcation (mathematical)
- Measurement-induced decoherence (quantum physics)
- Consciousness-mediated phase transition (neuroscience)

---

### State-Space Dynamics

**Official Term:** **State-Space Bifurcation**

**Definition:** The splitting of system dynamics into multiple branches following self-reference-induced decoherence at C_critical.

**Usage:** Preferred over "dimensional fracture," "dimensional split," "reality branching"

**Mathematical Context:** Bifurcation theory, dynamical systems

**Related Concepts:**
- Many-worlds interpretation (quantum mechanics)
- Phase space splitting (dynamical systems)
- Dimensional emergence (topology)

---

## OPERATIONAL VARIABLES

### Consciousness Measure Components

#### Integrated Information: Î¦(t)
**Source:** Integrated Information Theory (Tononi et al.)

**Definition:** Quantifies the amount of integrated information in a system, measuring irreducibility of cause-effect structure.

**Units:** bits

**Typical Range:** 0 (no integration) to ~10+ bits (high integration)

**Measurement:** Computed from connectivity matrices and state transitions

---

#### Self-Reference Completeness: R(t)
**Novel Contribution:** This framework

**Definition:** Degree to which a system models its own information processing, ranging from 0 (no self-modeling) to 1 (complete self-reference).

**Units:** Dimensionless, normalized [0,1]

**Operational Definition:**
- R = 0: No internal model of own states
- R = 0.5: Partial self-representation
- R = 1: Complete recursive self-modeling (theoretical limit)

**Measurement:** Ratio of self-directed information flow to total information flow

**Constraints:** R â†’ 1 is approached asymptotically but never reached in stable systems

---

#### Dimensional Embedding: D(t)
**Novel Contribution:** This framework

**Definition:** Effective dimensionality of the information space in which consciousness operates, quantifying representational capacity.

**Units:** Dimensionless

**Typical Range:** 1 (minimal) to 100+ (high-dimensional)

**Measurement:** Intrinsic dimensionality estimation from neural activity patterns

**Related Concepts:**
- Embedding dimension (topology)
- Degrees of freedom (physics)
- Representational capacity (neuroscience)

---

#### Consciousness Measure: C(t)
**Novel Synthesis:** This framework combines established and novel measures

**Definition:** C(t) = Î¦(t) Ã— R(t) Ã— D(t)

**Units:** bits (from Î¦ component)

**Critical Value:** C_crit â‰ˆ 8.3 Â± 0.6 bits

**Interpretation:**
- C < C_crit: Stable conscious state
- C â†’ C_crit: Approaching phase transition
- C â‰¥ C_crit: SRID triggered, bifurcation occurs

---

## MATHEMATICAL NOTATION STANDARDS

### Primary Equations

**Consciousness Measure:**
```
C(t) = Î¦(t) Ã— R(t) Ã— D(t)
```

**Critical Condition:**
```
C(t) â‰¥ C_crit â†’ SRID
```

**State Evolution with Bifurcation:**
```
Î¨_universe = Î£_branches âˆ« C(t) Ã— Î·(t) Ã— exp(-S/k_B) dt

When C(t) â‰¥ C_crit:
Î¨ â†’ Î£_i Î±_i |Ïˆ_iâŸ© + Î¨_PIS
```

**Critical Threshold (preliminary):**
```
C_crit = âˆš(â„/Î›) Ã— S_holographic
```

Where:
- â„: Reduced Planck constant
- Î›: Cosmological constant  
- S_holographic: Holographic entropy bound

---

### Notation Conventions

**State Vectors:**
- Î¨_PIS: Persistent information structure state
- Î¨_CCL: Consciousness computation layer state
- Î¨_MOL: Macroscopic observational layer state

**Operators:**
- Ä¤: Hamiltonian (energy operator)
- RÌ‚: Self-reference operator (novel)
- Î¦Ì‚: Integration operator

**Parameters:**
- Î»: Renormalization scale parameter
- Î²: Inverse temperature (1/k_B T)
- Ï„: Decoherence timescale

---

## PROCESS TERMINOLOGY

### Standard Terms (Keep As-Is)

**From Physics:**
- Phase transition
- Critical dynamics
- Criticality
- Decoherence
- Quantum coherence
- Entanglement
- Renormalization group flow

**From Neuroscience:**
- Neural avalanches
- Branching parameter (Ïƒ)
- Information integration
- Brain criticality
- Perturbational complexity

**From Mathematics:**
- Bifurcation
- Fixed point
- Strange loop (Hofstadter)
- Topology
- Dimensionality

**From Information Theory:**
- Entropy
- Mutual information
- Information conservation
- Holographic principle

---

### Novel/Modified Terms

**Self-Reference Phase Transition**
- Process by which increasing self-reference drives system toward criticality
- Distinguishes from other phase transition mechanisms

**Consciousness-Mediated Bifurcation**
- Emphasizes role of conscious observation in triggering state-space splitting
- Alternative to "measurement-induced collapse"

**Information Persistence**
- Conservation of core information patterns across bifurcations
- Mediated by persistent information structure

**Hierarchical Information Architecture**
- Multi-scale organization from quantum to macroscopic
- Each scale has distinct dynamics and observables

---

## COMPARATIVE TERMINOLOGY

### Relationship to Existing Theories

**Integrated Information Theory (IIT):**
- We use: Î¦ (integrated information)
- We add: R and D components
- We modify: Make Î¦ one component of C(t), not consciousness itself

**Global Neuronal Workspace (GNW):**
- They emphasize: Global broadcasting
- We interpret as: High Î¦ state enabling information integration
- Complementary, not competing

**Orchestrated Objective Reduction (Orch-OR):**
- They propose: Quantum effects in microtubules
- We: Agnostic about mechanism, focus on information-theoretic thresholds
- Compatible if quantum coherence reaches CCL

**Predictive Processing:**
- They emphasize: Prediction error minimization
- We interpret as: One mechanism maintaining C < C_crit
- Self-reference through prediction

**Free Energy Principle:**
- They propose: Minimize variational free energy
- We: Consistent with staying below C_crit (avoiding surprise)
- Complementary frameworks

---

## EXPERIMENTAL TERMINOLOGY

### Measurement Techniques

**Perturbational Complexity Index (PCI):**
- Established measure of consciousness level
- Predicted to show discontinuity at C_crit

**Lempel-Ziv Complexity (LZC):**
- Algorithmic complexity measure
- Should correlate with approach to C_crit

**Dynamic Functional Connectivity:**
- Time-varying brain network organization
- Expected to show criticality signatures

**Neuronal Avalanche Analysis:**
- Power-law distributed activity cascades
- Branching parameter Ïƒ â‰ˆ 1 at criticality

---

### Experimental Protocols

**Anesthesia Transition Studies:**
- Forward transition: Loss of consciousness (C_crit from above)
- Reverse transition: Emergence (C_crit from below)
- Hysteresis: Different thresholds forward vs. reverse

**TMS-EEG Perturbation:**
- Transcranial Magnetic Stimulation + EEG recording
- Tests system response at different C(t) values
- PCI as primary outcome measure

**Binocular Rivalry:**
- Spontaneous perceptual switching
- Natural probe of consciousness dynamics
- Tests C(t) fluctuations in awake state

---

## WRITING STYLE GUIDELINES

### Hedging Language

**Strong Claims (use rarely, with evidence):**
- "demonstrates"
- "proves"
- "shows definitively"

**Moderate Claims (use for well-supported novel ideas):**
- "suggests"
- "indicates"
- "provides evidence for"
- "is consistent with"

**Weak Claims (use for speculative extensions):**
- "may"
- "could"
- "might"
- "potentially"
- "if validated"

### Framing Novel Contributions

**First Mention of Framework:**
"We propose a Hierarchical Information-Reality Model (HIRM) in which..."

**Introducing New Concepts:**
"We define self-reference completeness R(t) as..."

**Making Predictions:**
"The framework predicts that [specific measurable outcome]..."

**Acknowledging Limitations:**
"This preliminary framework requires validation through..."

---

## LEGACY TERMINOLOGY (Popular Communication Only)

**These terms are RESERVED for popular books, talks, and public engagement:**

| Popular Term | Academic Equivalent |
|--------------|---------------------|
| The Ouroboros Observer | Hierarchical Information-Reality Model |
| Quantum DNA | Persistent Information Structure |
| The Ouroboros Event | Self-Reference-Induced Decoherence |
| Dimensional fracture/split | State-space bifurcation |
| The loop closes | Fixed-point convergence / Self-reference closure |
| Layer 1/2/3 (casual) | QIL/PIS, CCL, MOL |
| C-critical moment | Critical threshold / Phase transition point |
| Reality branching | State-space bifurcation / Many-worlds branching |
| The code layer | Quantum information layer |
| The display layer | Macroscopic observational layer |

---

## ABBREVIATION REFERENCE

### Framework Components
- **HIRM**: Hierarchical Information-Reality Model
- **PIS**: Persistent Information Structure
- **QIL**: Quantum Information Layer
- **CCL**: Consciousness Computation Layer
- **MOL**: Macroscopic Observational Layer
- **SRID**: Self-Reference-Induced Decoherence

### Variables
- **C(t)**: Consciousness measure (time-dependent)
- **C_crit** or **C***: Critical consciousness threshold
- **Î¦(t)**: Integrated information (IIT)
- **R(t)**: Self-reference completeness
- **D(t)**: Dimensional embedding

### Established Measures
- **PCI**: Perturbational Complexity Index
- **LZC**: Lempel-Ziv Complexity
- **IIT**: Integrated Information Theory
- **GNW**: Global Neuronal Workspace
- **FEP**: Free Energy Principle
- **RG**: Renormalization Group

---

## DISCIPLINE-SPECIFIC ADAPTATIONS

### For Physics Journals
**Emphasize:**
- Quantum information layer (QIL)
- Renormalization group flow
- Phase transitions and criticality
- Information conservation laws
- Mathematical rigor

**Terminology:**
- "State-space bifurcation"
- "Quantum coherence timescales"
- "Information-theoretic thresholds"

---

### For Neuroscience Journals
**Emphasize:**
- Brain criticality mechanisms
- Neural dynamics and avalanches
- Testable predictions with EEG/fMRI
- Clinical applications
- Consciousness measurement

**Terminology:**
- "Self-reference phase transitions"
- "Consciousness computation layer"
- "Critical brain dynamics"

---

### For Interdisciplinary Journals
**Emphasize:**
- Unification of existing theories
- Multi-scale framework
- Testable predictions across domains
- Philosophical implications (cautiously)

**Terminology:**
- "Hierarchical information-reality model"
- "Multi-scale architecture"
- "Information persistence mechanisms"

---

## CITATION FORMATTING

### First Framework Mention in Each Paper

**Format:**
"The Hierarchical Information-Reality Model (HIRM) [Self-cite when available] proposes that consciousness emerges through self-reference phase transitions at critical brain dynamics, with information persistence through conserved quantum invariants."

**After Papers Published:**
"...as proposed in the HIRM framework (Kirsch, 2025a; Kirsch, 2025b)..."

---

## VERSION CONTROL

**Current Version:** 1.0 (January 2025)

**Future Updates:**
- After peer review feedback: Refine definitions
- After experimental validation: Update predicted values
- After community adoption: Incorporate standard usage

**Change Log:**
- v1.0 (Jan 2025): Initial standardization from popular to academic terminology

---

## QUALITY CHECKS

### Before Submitting Any Paper:

âœ… All "Ouroboros" references removed (except possibly in acknowledgments)  
âœ… All "quantum DNA" replaced with "persistent information structure" or "quantum information layer"  
âœ… C-critical used consistently (not "C_critical" one place, "Ccrit" another)  
âœ… Layer naming consistent (QIL/PIS for Layer 1, CCL for Layer 2, MOL for Layer 3)  
âœ… SRID used for decoherence events (not "collapse" or "split")  
âœ… Hedging language appropriate for claim strength  
âœ… All variables defined on first use  
âœ… Notation consistent with this reference document  

---

## CONTACT & UPDATES

**Project Lead:** David Kirsch  
**Last Updated:** January 25, 2025  
**Next Review:** After first paper submission feedback  

**Usage:** Mandatory reference for all project writing. When in doubt, consult this document before introducing new terminology.

---

*This terminology reference is a living document. Suggest changes through project communication channels. All modifications require explicit approval before implementation.*
