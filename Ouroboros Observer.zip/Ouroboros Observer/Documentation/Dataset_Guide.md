# Published Consciousness Datasets for HIRM Validation
## Complete Access Guide with Direct Links

**Last Updated:** January 26, 2025  
**Purpose:** Immediate dataset download and analysis preparation

---

## TIER 1: Publicly Available (Immediate Access)

### 1. Sleep-EDF Database Expanded â­ TOP PRIORITY

**Description:** 197 whole-night polysomnography recordings with manual sleep staging

**Specifications:**
- **Subjects:** 197 (healthy + mild insomnia)
- **Duration:** Full night (typically 7-9 hours)
- **Sampling:** 100 Hz
- **Channels:** EEG (Fpz-Cz, Pz-Oz), EOG, EMG
- **Labels:** Manual R&K staging (W, N1, N2, N3, REM)
- **Format:** EDF files with accompanying hypnograms

**Access:**
- **URL:** https://www.physionet.org/content/sleep-edfx/1.0.0/
- **License:** Open Database License
- **Citation Required:** Kemp et al., IEEE-BME 47(9):1185-1194 (2000)

**Download Instructions:**
```bash
# Option 1: Direct download via wget
wget -r -N -c -np https://physionet.org/files/sleep-edfx/1.0.0/

# Option 2: Using Python (recommended)
pip install wfdb
import wfdb
wfdb.io.download('sleep-edfx', dl_dir='./sleep-edfx/')

# Option 3: MNE-Python
import mne
from mne.datasets import sleep_physionet
data_path = sleep_physionet.fetch_data(subjects=[0, 1, 2])
```

**File Structure:**
```
sleep-edfx/
â”œâ”€â”€ sleep-cassette/          # 153 PSG files (SC* files)
â”‚   â”œâ”€â”€ SC4001E0-PSG.edf     # PSG recording
â”‚   â”œâ”€â”€ SC4001EC-Hypnogram.edf  # Sleep staging
â”‚   â””â”€â”€ ...
â””â”€â”€ sleep-telemetry/         # 44 PSG files (ST* files)
    â”œâ”€â”€ ST7011J0-PSG.edf
    â”œâ”€â”€ ST7011JP-Hypnogram.edf
    â””â”€â”€ ...
```

**Analysis Priority:** START HERE
- Largest public dataset
- Gold standard manual staging
- Extensive use in literature (>500 citations)
- Perfect for C_crit threshold calibration

---

### 2. MASS (Montreal Archive of Sleep Studies)

**Description:** 200+ PSG recordings across multiple sleep conditions

**Specifications:**
- **Subjects:** 200+ (various sleep disorders)
- **Sampling:** 256 Hz
- **Channels:** 20+ EEG, EOG, EMG, ECG
- **Labels:** Expert staging + various annotations
- **Conditions:** Healthy, OSA, insomnia, RLS

**Access:**
- **URL:** http://ceams-carsm.ca/en/MASS/
- **License:** Free for research (registration required)
- **Citation:** O'Reilly et al., PLoS ONE 9(10):e109490 (2014)

**Download:**
```bash
# Register at CEAMS-CARSM website
# Download subsets (SS1, SS2, SS3, SS4, SS5)
# Total size: ~50 GB
```

**Advantage:** High-density EEG for better spatial resolution

---

### 3. PhysioNet EEG Motor Movement/Imagery Dataset

**Description:** 109 subjects performing motor tasks and imagery

**Specifications:**
- **Subjects:** 109 volunteers
- **Sampling:** 160 Hz
- **Channels:** 64 EEG (10-10 system)
- **Tasks:** Rest, motor execution, motor imagery
- **States:** Awake, varying attention/consciousness

**Access:**
- **URL:** https://physionet.org/content/eegmmidb/1.0.0/
- **License:** Open Database License

**Use Case:** Test C(t) in varying attention states (not sleep/anesthesia)

---

## TIER 2: Published Data (Request from Authors)

### 4. Cambridge Propofol Study â­ ANESTHESIA PRIORITY

**Description:** 20 healthy volunteers, propofol sedation with behavioral measures

**Specifications:**
- **Subjects:** 20 healthy adults
- **Agent:** Propofol (target-controlled infusion)
- **Sampling:** Likely 250-500 Hz
- **Channels:** High-density EEG
- **Events:** LOC/ROC behavioral markers
- **Published:** Chennu et al., PLoS Comput Biol (2016)

**Access Strategy:**
```
Contact: Dr. Srivas Chennu (srivas@gmail.com)
Institution: University of Kent / Cambridge
Paper: "Spectral signatures of reorganised brain networks in 
        disorders of consciousness"
Request: Raw EEG data with LOC/ROC timestamps
Justification: Testing phase transition predictions
```

**Critical for:** Phase transition validation at LOC/ROC

---

### 5. Casali TMS-EEG PCI Benchmark â­â­â­ GOLD STANDARD

**Description:** 150+ TMS-EEG sessions establishing PCI methodology

**Specifications:**
- **Subjects:** ~50 across multiple conditions
- **Conditions:** Wakefulness, NREM, anesthesia, VS, MCS
- **Sampling:** 1024 Hz (hd-EEG)
- **Measure:** PCI values for all sessions
- **Published:** Casali et al., Sci Transl Med 5(198):198ra105 (2013)

**Access Strategy:**
```
Primary Contact: Dr. Marcello Massimini (massimini@unimi.it)
Institution: University of Milan
Alternative: Dr. Adenauer Casali (adenauer.casali@ufabc.edu.br)

Request: 
1. Raw TMS-EEG data with PCI calculations
2. Concurrent resting-state EEG (if available)
3. Metadata: drug concentrations, behavioral scores

Justification: 
- Validate C(t) as PCI approximation
- Test hypothesis: C(t) correlates r>0.70 with PCI
- Demonstrate clinical utility without TMS requirement
```

**This dataset is CRITICAL for demonstrating C(t) clinical validity.**

---

### 6. Murphy Propofol High-Density EEG

**Description:** Propofol anesthesia with 256-channel EEG

**Specifications:**
- **Subjects:** 14
- **Agent:** Propofol
- **Sampling:** 500 Hz
- **Channels:** 256 (geodesic net)
- **Published:** Murphy et al., Sleep 34(3):283-291 (2011)

**Access:**
```
Contact: Dr. Michael Murphy (University of Wisconsin-Madison)
Email: Available through institutional directory
Paper: "Propofol Anesthesia and Sleep: A High-Density EEG Study"
```

**Advantage:** Highest spatial resolution for topology analysis

---

### 7. Warnaby Anesthesia LOC/ROC Dataset

**Description:** Multiple anesthetics with precise LOC/ROC timing

**Specifications:**
- **Subjects:** 60+ across multiple studies
- **Agents:** Propofol, sevoflurane, xenon, ketamine
- **Measures:** EEG + behavioral response
- **Published:** Warnaby et al., Br J Anaesth (2017, 2021)

**Access:**
```
Contact: Dr. Catherine Warnaby (University of Oxford)
Email: catherine.warnaby@ndcn.ox.ac.uk
Papers: Multiple in BJA and Anesthesiology
```

**Advantage:** Cross-agent comparison (test universality of C_crit)

---

## TIER 3: Clinical Datasets (Requires Collaboration/IRB)

### 8. LiÃ¨ge DOC Multimodal Dataset

**Description:** Disorders of consciousness with PCI, fMRI, PET

**Specifications:**
- **Subjects:** 300+ patients (VS, MCS, EMCS, LIS)
- **Measures:** PCI, fMRI, behavioral assessment
- **Institution:** University of LiÃ¨ge (Coma Science Group)
- **Leader:** Steven Laureys

**Access:**
- **Collaboration required** (not public)
- **IRB approval** needed
- **Data sharing agreement**

**Timeline:** 6-12 months from initial contact

---

### 9. Cambridge Consciousness Disorders Database

**Description:** Large prospective DOC study with multiple measures

**Specifications:**
- **Subjects:** 365 ICU patients
- **Measures:** Behavioral, EEG, fMRI, PET
- **Published:** Amiri et al., Brain 146(1):50-64 (2023)

**Access:**
- **Contact:** Dr. Adrian Owen (Western University)
- **Collaboration:** Likely required

---

## TIER 4: Commercial/Proprietary (Future Consideration)

### 10. BIS Anesthesia Monitoring Database

**Description:** Thousands of surgeries with BIS monitoring

**Specifications:**
- **Source:** Covidien/Medtronic clinical trials
- **Scale:** 10,000+ cases
- **Measures:** BIS, EEG, drug concentrations

**Access:** Requires commercial partnership or FDA collaboration

---

## Recommended Analysis Sequence

### Phase 1 (Weeks 1-4): Public Dataset Validation
```
Week 1-2: Sleep-EDF Dataset
- Download all 197 subjects
- Preprocess and quality check
- Calculate C(t) for all epochs
- Optimize C_crit threshold
- Generate manuscript figures

Week 3-4: MASS Dataset (if time permits)
- Validate on independent sleep dataset
- Test generalization
- Compare high-density vs low-density EEG
```

**Deliverable:** Paper 1 draft ready

### Phase 2 (Months 2-3): Anesthesia Dataset Access
```
Month 2: Contact Cambridge/Oxford groups
- Request Chennu propofol data
- Request Murphy high-density data
- Explain HIRM framework and predictions

Month 3: Anesthesia Analysis
- Calculate C(t) around LOC/ROC
- Test phase transition predictions
- Compare with published spectral analyses
```

**Deliverable:** Paper 2 draft ready

### Phase 3 (Months 4-6): PCI Gold Standard Validation
```
Month 4-5: Contact Milan group
- Present Sleep-EDF + anesthesia results
- Request PCI benchmark data
- Negotiate data sharing agreement

Month 6: PCI Correlation Analysis
- C(t) vs PCI correlation
- ROC curves for consciousness detection
- Demonstrate clinical utility
```

**Deliverable:** Paper 3 draft ready

---

## Dataset Selection Criteria

### Prioritize datasets that offer:

âœ… **Clear consciousness labels** (manual staging, LOC/ROC markers, PCI values)  
âœ… **Sufficient transitions** (multiple wake-sleep or conscious-unconscious)  
âœ… **Good signal quality** (artifact-free epochs)  
âœ… **Published benchmarks** (can compare with existing analyses)  
âœ… **Public or requestable** (feasible to obtain)  

### Avoid datasets with:

âŒ Heavy artifacts (movement, muscle activity)  
âŒ Unclear state labels  
âŒ Proprietary restrictions  
âŒ Poor documentation  

---

## Data Processing Pipeline

### Standard Preprocessing
```python
import mne

# Load EDF file
raw = mne.io.read_raw_edf('SC4001E0-PSG.edf', preload=True)

# Filter
raw.filter(l_freq=0.5, h_freq=45, method='fir')

# Resample to 100 Hz (standardize)
raw.resample(sfreq=100)

# Epoch (30-sec for sleep, 5-sec for anesthesia transitions)
epochs = mne.make_fixed_length_epochs(raw, duration=30.0, preload=True)

# Artifact rejection (amplitude threshold, variance threshold)
epochs.drop_bad(reject={'eeg': 200e-6})  # 200 ÂµV threshold

# Extract data
data = epochs.get_data()  # shape: (n_epochs, n_channels, n_samples)
```

### HIRM Analysis
```python
from hirm_framework import HIRMFramework

hirm = HIRMFramework(sfreq=100, window_sec=30)

C_values = []
for epoch_data in data:
    c_dict = hirm.calculate_C(epoch_data)
    C_values.append(c_dict['C'])

C_values = np.array(C_values)
```

---

## Budget Estimate (if data purchase required)

| Item | Cost | Notes |
|------|------|-------|
| Sleep-EDF | **FREE** | Public domain |
| MASS | **FREE** | Registration only |
| Cambridge propofol | **FREE** (request) | Collaboration |
| Casali PCI | **FREE** (request) | May require MTA |
| Commercial datasets | $10,000-$50,000 | Only if needed for replication |

**Total estimated cost: $0** for Phase 1-3 analyses

---

## Timeline Summary

| Phase | Duration | Dataset | Deliverable |
|-------|----------|---------|-------------|
| **Proof-of-concept** | âœ… Complete | Synthetic | Framework validated |
| **Phase 1** | Weeks 1-4 | Sleep-EDF | Paper 1 draft |
| **Phase 2** | Months 2-3 | Propofol | Paper 2 draft |
| **Phase 3** | Months 4-6 | PCI benchmark | Paper 3 draft |
| **Phase 4** | Months 6-12 | Clinical DOC | Validation studies |

---

## Quick Start Commands

### Download Sleep-EDF immediately:
```bash
# Create project directory
mkdir -p ~/hirm_validation/data/sleep_edf

# Download dataset (Option 1: wget)
cd ~/hirm_validation/data/sleep_edf
wget -r -N -c -np https://physionet.org/files/sleep-edfx/1.0.0/

# Or use Python script (recommended)
python3 << EOF
import urllib.request
import os

base_url = "https://physionet.org/files/sleep-edfx/1.0.0/sleep-cassette/"
subjects = [f"SC40{i:02d}" for i in range(1, 62)]  # SC4001-SC4061

os.makedirs("sleep-cassette", exist_ok=True)

for subj in subjects:
    for suffix in ["E0-PSG.edf", "EC-Hypnogram.edf"]:
        filename = f"{subj}{suffix}"
        url = base_url + filename
        try:
            print(f"Downloading {filename}...")
            urllib.request.urlretrieve(url, f"sleep-cassette/{filename}")
        except:
            print(f"  -> File {filename} not found, skipping")
EOF
```

**Start analyzing in <1 hour after running this.**

---

## Contact Information for Data Requests

### Sleep Studies:
- **PhysioNet:** support@physionet.org
- **MASS:** Christian O'Reilly (christian.oreilly@epfl.ch)

### Anesthesia Studies:
- **Cambridge:** Srivas Chennu (srivas@gmail.com)
- **Oxford:** Catherine Warnaby (catherine.warnaby@ndcn.ox.ac.uk)
- **Wisconsin:** Michael Murphy (via department)

### PCI Gold Standard:
- **Milan:** Marcello Massimini (massimini@unimi.it)
- **Brazil:** Adenauer Casali (adenauer.casali@ufabc.edu.br)

### DOC Clinical:
- **LiÃ¨ge:** Steven Laureys (steven.laureys@uliege.be)
- **Cambridge:** Adrian Owen (via Western University)

---

## Email Template for Data Requests

```
Subject: Request for EEG Data Access - Consciousness Phase Transition Study

Dear Dr. [NAME],

I am writing to request access to the EEG dataset from your 
[YEAR] [JOURNAL] publication "[TITLE]" for use in validating 
a novel consciousness measurement framework.

I am developing the Hierarchical Information-Reality Model (HIRM), 
which proposes that consciousness emerges through a phase transition 
at a critical information threshold. The framework predicts:

1. Discontinuous jump in complexity measures at LOC/ROC
2. Universal threshold C_crit â‰ˆ 8.3 bits across agents
3. Strong correlation with established measures (PCI, BIS)

Your dataset would be invaluable for testing these predictions 
because [SPECIFIC REASON FOR THIS DATASET].

I am prepared to:
- Sign a data use agreement
- Provide proper attribution in all publications
- Share analysis code and results before publication
- Acknowledge your contribution as appropriate

Would you be willing to share the raw EEG data and associated 
consciousness labels? I can provide more details about the analysis 
plan if helpful.

Thank you for considering this request.

Best regards,
David Kirsch
[Your affiliation/contact info]
```

---

## Bottom Line

**Immediate action:** Download Sleep-EDF (takes 30-60 minutes)

**Week 1 goal:** First real-dataset C(t) analysis complete

**Month 1 goal:** Sleep-EDF full analysis with optimized C_crit

**Month 3 goal:** Anesthesia phase transition validation

**Month 6 goal:** PCI correlation established

**All necessary information provided above to execute immediately.** ðŸš€

---

**Last Updated:** January 26, 2025  
**Next Update:** After Sleep-EDF analysis complete
